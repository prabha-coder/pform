<?php
//Slience is golden.